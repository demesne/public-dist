# Vesperline prompt — dependency-free, git-aware, and truecolor-capable.
autoload -Uz add-zsh-hook vcs_info
setopt prompt_subst

if [[ ${VESPERLINE_VARIANT:-dark} == light ]]; then
  VESPERLINE_PINK='#C72055' VESPERLINE_YELLOW='#7A5D00' VESPERLINE_GREEN='#4E7218'
  VESPERLINE_CYAN='#00758A' VESPERLINE_PURPLE='#6943A3' VESPERLINE_MUTED='#727072'
  VESPERLINE_GIT_LABEL='#514E52' VESPERLINE_GIT_BRANCH='#2D2A2E' VESPERLINE_GIT_STATE='#7A5D00'
else
  VESPERLINE_PINK='#FF6188' VESPERLINE_YELLOW='#FFD866' VESPERLINE_GREEN='#A9DC76'
  VESPERLINE_CYAN='#78DCE8' VESPERLINE_PURPLE='#AB9DF2' VESPERLINE_MUTED='#939293'
  VESPERLINE_GIT_LABEL='#C1C0C0' VESPERLINE_GIT_BRANCH='#FCFCFA' VESPERLINE_GIT_STATE='#FFD866'
fi

zstyle ':vcs_info:git:*' formats " %%F{${VESPERLINE_GIT_LABEL}}git:%%F{${VESPERLINE_GIT_BRANCH}}%b%%f%%F{${VESPERLINE_GIT_STATE}}%u%c%%f"
zstyle ':vcs_info:git:*' actionformats " %%F{${VESPERLINE_GIT_LABEL}}git:%%F{${VESPERLINE_GIT_BRANCH}}%b%%f %%F{${VESPERLINE_GIT_STATE}}(%a)%%f"
zstyle ':vcs_info:*' check-for-changes true
zstyle ':vcs_info:*' unstagedstr '*'
zstyle ':vcs_info:*' stagedstr '+'

_vesperline_precmd() {
  local exit_code=$?
  vcs_info
  VESPERLINE_EXIT=""
  (( exit_code != 0 )) && VESPERLINE_EXIT="%F{${VESPERLINE_PINK}}${exit_code} %f"
}
add-zsh-hook -d precmd _vesperline_precmd 2>/dev/null
add-zsh-hook precmd _vesperline_precmd

PROMPT='%F{${VESPERLINE_GREEN}}%n%f%F{${VESPERLINE_MUTED}}@%f%F{${VESPERLINE_CYAN}}%m%f %F{${VESPERLINE_CYAN}}%~%f${vcs_info_msg_0_}
${VESPERLINE_EXIT}%F{${VESPERLINE_YELLOW}}❯%f '
RPROMPT='%F{${VESPERLINE_MUTED}}%D{%H:%M}%f'
