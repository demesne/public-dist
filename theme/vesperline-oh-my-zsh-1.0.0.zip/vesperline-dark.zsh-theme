export VESPERLINE_VARIANT=dark
source "${0:A:h}/vesperline.zsh-theme"
