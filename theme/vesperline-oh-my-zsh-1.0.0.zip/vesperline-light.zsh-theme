export VESPERLINE_VARIANT=light
source "${0:A:h}/vesperline.zsh-theme"
